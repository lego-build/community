<script>
export default {
  props: [],
};
</script>

<template>
  <div></div>
</template>

<style scoped></style>
