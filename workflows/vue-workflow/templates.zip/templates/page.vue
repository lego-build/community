<script>
export default {
  props: [],
};
</script>

<template>
  <section></section>
</template>

<style scoped></style>
