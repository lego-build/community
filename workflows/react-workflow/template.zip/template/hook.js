import React, { useState, useEffect } from "react";

function useblockName() {
  const [state, setState] = useState();

  useEffect(() => {}, [state]);

  return [state];
}

export default useblockName;
