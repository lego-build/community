import { createContext, useState } from "react";

const blockNameContext = createContext({});

const blockNameContextProvider = ({ children }) => {
  const [contextState, setcontextState] = useState({
    // All values goes here.
  });
  return (
    <blockNameContext.Provider value={{ contextState }}>
      {children}
    </blockNameContext.Provider>
  );
};
