import React from "react";

function blockName() {
  return <div> blockName </div>;
}

export default blockName;
