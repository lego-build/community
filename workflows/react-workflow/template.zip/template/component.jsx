import { View } from "react-native";
import styles from "./styles";

function blockName() {
  return <div> blockName </div>;
}

export default blockName;
