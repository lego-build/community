function blockName(arg) {
  return arg;
}
export default blockName;
