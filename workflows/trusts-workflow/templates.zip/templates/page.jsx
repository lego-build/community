import React from "react";
import style from "./index.module.css";

function blockName() {
  return <section className={style.blockName}>blockName</section>;
}

export default blockName;
