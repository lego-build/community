import React from "react";
import style from "./index.module.css";

function blockName() {
  return <div className={style.blockName}>blockName</div>;
}

export default blockName;
