import { View } from "react-native";
import styles from "./styles";

function blockName() {
  return <View style={styles}></View>;
}

export default blockName;
