export const blockName = (payload:any) => {
    return { type: "ACTION_TYPE", payload };
};