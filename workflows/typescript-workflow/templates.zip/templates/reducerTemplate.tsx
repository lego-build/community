type IblockState = any;
export const blockName: IblockState = (state: IblockState = null, action: string) => {
    switch (action) {
      default:
        return state;
    }
  };