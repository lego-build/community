import * as React from "react";
interface IblockProps {
}
const  blockName:React.FC<IblockProps> = () => {
  return <div></div>;
}

export default blockName;