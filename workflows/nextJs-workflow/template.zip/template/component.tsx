import  React, { FC } from 'react';

export interface IblockNameProps {
}

const blockName: FC<IblockNameProps> = (props) => {
  return (
    <section>
      blockName
    </section>
  );
}
export default blockName;