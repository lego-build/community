import React, { FC } from 'react';
import type { IconProps, Props, PropTypes } from "../../typescript";



const blockName: FC<PropTypes<Props, IconProps>> = (props) => {
    return (
        <>
            blockName
        </>
    );
}
export default blockName;