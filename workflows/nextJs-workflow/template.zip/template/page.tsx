import type { NextPage } from 'next'

export interface IblockNameProps {
}

const blockName: NextPage<IblockNameProps> = () => {
  return (
    <section>
      blockName
    </section>
  );
}
export default blockName;